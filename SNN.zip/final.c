#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define AXONS 256
#define NEURONS_PER_CORE 256
#define NUM_CORES 1
#define FIFO_SIZE 256
#define NUM_PACKETS 256
#define MAX_SPIKE_EVENTS 1000
// #define SYNAPSES 32

typedef struct
{
    int current_membrane_potential : 9;
    int reset_posi_potential : 9;
    int weights_0 : 9;
    int weights_1 : 9;
    int weights_2 : 9;
    int weights_3 : 9;
    int leakage_value : 9;
    int positive_threshold : 9;
    int negative_threshold : 9;
    int reset_mode : 1;
    int dx : 9;
    int dy : 9;
    unsigned int destination_axon : 8;
    int destination_ticks : 4;
} Neuron;
typedef struct
{
    int packet_dx : 9;
    int packet_dy : 9;
    unsigned int packet_destination_axon : 8;
    int packet_destination_ticks : 4;
} packet_in;

typedef struct
{
    int front, rear, size;
    unsigned capacity;
    int *array;
} Queue;

typedef struct
{
    packet_in packets[NUM_PACKETS];
    Neuron neurons[NEURONS_PER_CORE];
    uint8_t synapse_connections[AXONS][NEURONS_PER_CORE];
    // uint8_t large_synapse_connections[NEURONS_PER_CORE][AXONS];
    // Queue destinationAxonQueue;
    Queue output_spike;
    Queue InputSpike;
    uint8_t output_axons[NEURONS_PER_CORE];
} SNNCore;

SNNCore cores[NUM_CORES];

Queue *createQueue(unsigned capacity)
{
    Queue *queue = (Queue *)malloc(sizeof(Queue));
    queue->capacity = capacity;
    queue->front = queue->size = 0;
    queue->rear = capacity - 1;
    queue->array = (int *)malloc(queue->capacity * sizeof(int));
    return queue;
}

int isFull(Queue *queue) { return (queue->size == queue->capacity); }
int isEmpty(Queue *queue) { return (queue->size == 0); }

void enqueue(Queue *queue, int item)
{
    if (isFull(queue))
        return;
    queue->rear = (queue->rear + 1) % queue->capacity;
    queue->array[queue->rear] = item;
    queue->size = queue->size + 1;
}

int dequeue(Queue *queue)
{
    if (isEmpty(queue))
        return -1;
    int item = queue->array[queue->front];
    queue->front = (queue->front + 1) % queue->capacity;
    queue->size = queue->size - 1;
    return item;
}

int front(Queue *queue)
{
    if (isEmpty(queue))
        return -1;
    return queue->array[queue->front];
}

void clearQueue(Queue *q) {
    while (!isEmpty(q)) {
        dequeue(q);
    }
}

void printBinary(int num, int bits)
{
    for (int bit = bits - 1; bit >= 0; bit--)
    {
        printf("%d", (num >> bit) & 1);
    }
    printf("\n");
}

void readNeuronData(SNNCore *core, const char *line, int neuronIndex)
{
    // printf("Synaptic connection:");
    for (int i = 0; i < AXONS; i++)
    {
        core->synapse_connections[i][neuronIndex] = line[i] - '0';
        // printf("%d",  core->synapse_connections[i][neuronIndex]);
    }
    // printf("\n");

    int params[9];
    for (int i = 0, j = AXONS; i < 9; i++, j += 9)
    {
        int value = 0;
        for (int k = 0; k < 9; k++)
        {
            value = (value << 1) | (line[j + k] - '0');
        }
        params[i] = value;
    }

    Neuron *neuron = &core->neurons[neuronIndex];
    neuron->current_membrane_potential = params[0];
    neuron->reset_posi_potential = params[1];
    neuron->weights_0 = params[2];
    neuron->weights_1 = params[3];
    neuron->weights_2 = params[4];
    neuron->weights_3 = params[5];
    neuron->leakage_value = params[6];
    neuron->positive_threshold = params[7];
    neuron->negative_threshold = params[8];
    int params0;
    for (int i = 0, j = AXONS + 81; i < 1; i++, j += 1)
    {
        int value = 0;
        for (int k = 0; k < 1; k++)
        {
            value = (value << 1) | (line[j + k] - '0');
        }
        params0 = value;
    }
    neuron->reset_mode = params0;
    int params3[2];
    for (int i = 0, j = AXONS + 82; i < 2; i++, j += 9)
    {
        int value = 0;
        for (int k = 0; k < 9; k++)
        {
            value = (value << 1) | (line[j + k] - '0');
        }
        params3[i] = value;
    }
    neuron->dx = params3[0];
    neuron->dy = params3[1];
    int params1;
    for (int i = 0, j = AXONS + 100; i < 1; i++, j += 8)
    {
        int value = 0;
        for (int k = 0; k < 8; k++)
        {
            value = (value << 1) | (line[j + k] - '0');
        }
        params1 = value;
    }
    neuron->destination_axon = params1; // Sử dụng 8 bit cho destination_axon
    int params2;
    for (int i = 0, j = AXONS + 108; i < 1; i++, j += 4)
    {
        int value = 0;
        for (int k = 0; k < 4; k++)
        {
            value = (value << 1) | (line[j + k] - '0');
        }
        params2 = value;
    }
    neuron->destination_ticks = params2;

    // printf("Current Membrane Potential: ");
    // printBinary(neuron->current_membrane_potential, 9);
    // printf("Reset Positive Potential: ");
    // printBinary(neuron->reset_posi_potential, 9);
    // printf("Weight 0: ");
    // printBinary(neuron->weights_0, 9);
    // printf("Weight 1: ");
    // printBinary(neuron->weights_1, 9);
    // printf("Weight 2: ");
    // printBinary(neuron->weights_2, 9);
    // printf("Weight 3: ");
    // printBinary(neuron->weights_3, 9);
    // printf("Leakage Value: ");
    // printBinary(neuron->leakage_value, 9);
    // printf("Positive Threshold: ");
    // printBinary(neuron->positive_threshold, 9);
    // printf("Negative Threshold: ");
    // printBinary(neuron->negative_threshold, 9);
    // printf("Reset Mode: ");
    // printBinary(neuron->reset_mode, 1);
    // printf("dx: ");
    // printBinary(neuron->dx, 9);
    // printf("dy: ");
    // printBinary(neuron->dy, 9);
    // printf("Destination Axon: ");
    // printBinary(neuron->destination_axon, 8);
    // printf("Destination Ticks: ");
    // printBinary(neuron->destination_ticks, 4);
}

int getNeuronData(SNNCore cores[])
{
    FILE *file = fopen("neuron_data.txt", "r");
    if (file == NULL)
    {
        printf("Unable to open file.\n");
        return 1;
    }
    char line[AXONS + 116];
    int coreIndex = 0, neuronIndex = 0;
    int neuronCount = 0; // Đếm số neuron đã in

    while (fgets(line, sizeof(line), file))
    {
        if (neuronCount >= 256)
        {
            break; // Đã in đủ 256 neurons, kết thúc việc in
        }

        if (neuronCount >= 0 && neuronCount < NUM_CORES * NEURONS_PER_CORE)
        {
            // In thông tin neuron
            // printf("Neuron %d\n", neuronCount);
            readNeuronData(&cores[coreIndex], line, neuronIndex);
            neuronIndex++;
            // printf("\n");
            neuronCount++;
        }

        // Điều chỉnh index cho core và neuron
        if (neuronIndex >= NEURONS_PER_CORE)
        {
            neuronIndex = 0;
            coreIndex++;
            if (coreIndex >= NUM_CORES)
            {
                break; // Đã duyệt qua tất cả các cores
            }
        }
    }
    fclose(file);
    return 0;
}

int getWeight(Neuron *neuron, int index)
{
    switch (index)
    {
    case 0:
        return neuron->weights_0;
    case 1:
        return neuron->weights_1;
    case 2:
        return neuron->weights_2;
    case 3:
        return neuron->weights_3;
    default:
        return 0; // Giá trị mặc định hoặc xử lý lỗi
    }
}

unsigned int **spike_out_neuron[NUM_CORES][NEURONS_PER_CORE];
int StoredSpikeOutCount[NUM_CORES][NEURONS_PER_CORE] = {{0}};
Queue output_spike;
Queue indexQueue;

void processSpikeEvent(SNNCore *core, int coreIndex, int num_neuron, int axonIndex, int count, int num_packet, FILE *output_file)
{
    // FILE *output_file = fopen("parameter_after.txt", "a");
    Neuron *neuron = &core->neurons[num_neuron];
    // fprintf(output_file, "neuron %d neuron_connection %d\n", num_neuron, core->synapse_connections[255 - axonIndex][num_neuron]);
    // fprintf(output_file, "neuron %d va packet %d weight %d\n", num_neuron, axonIndex, getWeight(neuron, axonIndex % 4));
    neuron->current_membrane_potential += (getWeight(neuron, axonIndex % 4) * core->synapse_connections[255 - axonIndex][num_neuron]);

    // fprintf(output_file, "neuron %d leak_potential %d\n", num_neuron, neuron->current_membrane_potential);
    if (num_packet == count - 1)
    {
        neuron->current_membrane_potential += neuron->leakage_value;
        // fprintf(output_file, "neuron %d leak_potential final %d\n", num_neuron, neuron->current_membrane_potential);
        if (neuron->current_membrane_potential >= neuron->positive_threshold)
        {
            neuron->current_membrane_potential = neuron->reset_posi_potential;
            core->output_axons[num_neuron] = 1;
            enqueue(&cores[coreIndex].output_spike, 1);
            // fprintf(output_file, "%d->neuron %d này có bắn spike tai axon %d\n", core->output_axons[num_neuron], num_neuron, axonIndex);
            fprintf(output_file, "%d", 1);
        }
        else if (neuron->current_membrane_potential < neuron->negative_threshold)
        {
            neuron->current_membrane_potential = neuron->reset_posi_potential;
            core->output_axons[num_neuron] = 0;
            enqueue(&cores[coreIndex].output_spike, 0);
            // fprintf(output_file, "%d->neuron %d này không bắn spike\n", core->output_axons[num_neuron], num_neuron);
            fprintf(output_file, "%d", 0);
        }
    }
    else
    {
        neuron->current_membrane_potential = neuron->current_membrane_potential;
    }
}

// void readPacketData(SNNCore *core, const char *line, int packetIndex)
// {
//     Queue *destinationAxonQueue = createQueue(NUM_PACKETS);
//     Queue *lastdestinationAxonQueue = NULL;
//     for (int coreIndex = 0; coreIndex < NUM_CORES; coreIndex++)
//     {
//         int params[2];
//         for (int i = 0, j = 0; i < 9; i++, j += 9)
//         {
//             int value = 0;
//             for (int k = 0; k < 9; k++)
//             {
//                 value = (value << 1) | (line[j + k] - '0');
//             }
//             params[i] = value;
//         }

//         packet_in *packet = &core->packets[packetIndex];
//         packet->packet_dx = params[0];
//         packet->packet_dy = params[1];
//         int params0;
//         for (int i = 0, j = 18; i < 1; i++, j += 8)
//         {
//             int value = 0;
//             for (int k = 0; k < 8; k++)
//             {
//                 value = (value << 1) | (line[j + k] - '0');
//             }
//             params0 = value;
//         }
//         packet->packet_destination_axon = params0;
//         enqueue(&cores[coreIndex].destinationAxonQueue, packet->packet_destination_axon);

//         int params1;
//         for (int i = 0, j = 26; i < 1; i++, j += 4)
//         {
//             int value = 0;
//             for (int k = 0; k < 4; k++)
//             {
//                 value = (value << 1) | (line[j + k] - '0');
//             }
//             params1 = value;
//         }
//         packet->packet_destination_ticks = params1;
//         lastdestinationAxonQueue = destinationAxonQueue;
//     }
// }

// int getPacketData(SNNCore cores[])
// {
//     FILE *file = fopen("tb_input.txt", "r");
//     if (file == NULL)
//     {
//         printf("Unable to open file.\n");
//         return 1;
//     }
//     char line[34];
//     int coreIndex = 0, packetIndex = 0;
//     int packetCount = 0; // Đếm số packet đã in

//     while (fgets(line, sizeof(line), file))
//     {

//         if (packetCount >= 0 && packetCount < NUM_PACKETS)
//         {
//             // In thông tin neuron
//             // printf("Packet %d\n", packetCount);
//             readPacketData(&cores[coreIndex], line, packetIndex);
//             packetIndex++;
//             // printf("\n");
//             packetCount++;
//         }

//         // Điều chỉnh index cho core và packet
//         if (packetIndex >= NEURONS_PER_CORE)
//         {
//             packetIndex = 0;
//             coreIndex++;
//             if (coreIndex >= NUM_CORES)
//             {
//                 break; // Đã duyệt qua tất cả các cores
//             }
//         }
//     }
//     fclose(file);
//     return 0;
// }

int getPacketData(SNNCore cores[], int start)
{
    FILE *file1 = fopen("tb_num_input.txt", "r");
    FILE *file2 = fopen("tb_input.txt", "r");

    if (file1 == NULL || file2 == NULL)
    {
        printf("Unable to open one or both files.\n");
        return 1;
    }

    int lineCount = 0;
    char line1[100000];
    char line2[100000];
    int readOnce = 0;
    while (fgets(line1, sizeof(line1), file1))
    {
        lineCount++;
        int count = atoi(line1);
        printf("Reading %d lines from file 2 for value %d\n", count, atoi(line1));

        for (int h = start; h < start + count && fgets(line2, sizeof(line2), file2); h++)
        {
            int params[2];
            for (int i = 0, j = 0; i < 9; j++, i += 9)
            {
                int value = 0;
                for (int k = 0; k < 9; k++)
                {
                    value = (value << 1) | (line2[j + k] - '0');
                }
                params[i] = value;
            }

            int coreIndex = params[1];
            packet_in *packet = &cores[coreIndex].packets[cores[coreIndex].InputSpike.rear];
            packet->packet_dx = params[0];
            packet->packet_dy = params[1];
            int params0;
            for (int x = 0, y = 18; x < 1; x++, y += 8)
            {
                int value1 = 0;
                for (int k = 0; k < 8; k++)
                {
                    value1 = (value1 << 1) | (line2[y + k] - '0');
                }
                params0 = value1;
            }
            packet->packet_destination_axon = params0;

            enqueue(&(cores[coreIndex].InputSpike), packet->packet_destination_axon);
            // printQueue(&cores[coreIndex].InputSpike);
            int params1;
            for (int x = 0, y = 26; x < 1; x++, y += 4)
            {
                int value = 0;
                for (int k = 0; k < 4; k++)
                {
                    value = (value << 1) | (line2[y + k] - '0');
                }
                params1 = value;
            }
            packet->packet_destination_ticks = params1;

            // printf("Line 2 value: %d\n",packet->packet_dx);
            // printf("Line 2 value: %d\n",packet->packet_dy);
            // printf("Line 2 value: %d\n",params0);
            // printf("Line 2 value: %d\n",packet->packet_destination_ticks);
        }
        start += count;

        FILE *output_file = fopen("output_file.txt", "a");
        if (output_file == NULL)
        {
            printf("Unable to open output file!\n");
            return 1;
        }
        for (int i = 0; i < NUM_CORES; i++)
        {
            // for (int j = 0; j <= lineCount-1; j++) {
            // printf("Core %d\n", i);
            printQueue(&cores[i].InputSpike);
            // fprintf(output_file, "===== Core %d =====\n", i);
            // printf("%d\n",count);
            for (int j = 0; j < NEURONS_PER_CORE; j++)
            {

                int num_packet = 0;
                // Queue *currentCoreInput = &cores[i].InputSpike;
                // while (!isEmpty(&currentCoreInput))
                for (int lap = 0; lap < count; lap++)
                {
                    int axonIndex = dequeue(&cores[i].InputSpike);
                    // printf("haha %d\n",lap);
                    processSpikeEvent(&cores[i], i, j, axonIndex, count, num_packet, output_file);
                    // printQueue(&cores[i].InputSpike);
                    num_packet++;
                    enqueue(&cores[i].InputSpike, axonIndex);
                }  
            }
            clearQueue(&(cores[i].InputSpike));
            // saveOutputAxons(cores, "output_axons.txt",lineCount);
            fprintf(output_file, "\n");
            // }
        }

        fclose(output_file);
        // }
    }

    fclose(file1);
    fclose(file2);
    return 0;
}

void printQueue(const Queue *queue)
{
    printf("Queue contents: \n");
    for (int i = queue->front; i <= queue->rear; i++)
    {
        printf("%d ", queue->array[i]);
    }
    printf("\n");
}

// void initializeCoreQueues()
// {
//     for (int i = 0; i < NUM_CORES; i++)
//     {
//         cores[i].destinationAxonQueue = *createQueue(FIFO_SIZE);
//     }
// }
void initializeCoreQueues()
{
    for (int i = 0; i < NUM_CORES; i++)
    {
        cores[i].InputSpike = *createQueue(NUM_PACKETS);
    }
}
void initializeOutputSpikeQueue()
{
    for (int i = 0; i < NUM_CORES; i++)
    {
        cores[i].output_spike = *createQueue(FIFO_SIZE);
    }
}

int main()
{
    Queue *InputSpike = createQueue(NUM_PACKETS);
    initializeCoreQueues();
    initializeOutputSpikeQueue();
    if (getNeuronData(cores))
    {
        return 1; // Error in reading data
    }
    if (getPacketData(cores, 0))
    {
        return 1; // Error in reading data
    }

    // for (int i = 0; i < NUM_CORES; i++)
    // {
    //     printQueue(&cores[i].destinationAxonQueue);
    //     for (int j = 0; j < NEURONS_PER_CORE; j++)
    //     {
    //         int num_packet = 0;
    //         // while (!isEmpty(&cores[i].destinationAxonQueue)) {
    //         for (int lap = 0; lap < 16; lap++)
    //         {
    //             int axonIndex = dequeue(&cores[i].destinationAxonQueue);
    //             processSpikeEvent(&cores[i], i, j, axonIndex, num_packet);
    //             num_packet++;
    //             enqueue(&cores[i].destinationAxonQueue,axonIndex);
    //         }
    //     }
    // }
    // for (int i = 0; i < NUM_CORES; i++)
    // {
    //     printQueue(&cores[i].output_spike);
    // }
    return 0;
}
